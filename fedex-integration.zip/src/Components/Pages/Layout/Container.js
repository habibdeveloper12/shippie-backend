const Container = ({ children }) => {
  return <div className="lg:max-w-container mx-auto">{children}</div>;
};

export default Container;
