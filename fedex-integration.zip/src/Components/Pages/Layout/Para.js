import React from "react";

const Para = ({ className, title }) => {
  return <p className={className}>{title}</p>;
};

export default Para;
